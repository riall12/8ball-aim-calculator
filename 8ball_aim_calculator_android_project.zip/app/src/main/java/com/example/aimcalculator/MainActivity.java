package com.example.aimcalculator;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.view.*;
import android.widget.*;
import android.content.Context;

public class MainActivity extends Activity {
    AimTableView table;
    TextView status;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(16,37,29));
        getWindow().setNavigationBarColor(Color.rgb(16,37,29));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(16,37,29));
        root.setPadding(dp(14), dp(12), dp(14), dp(12));

        TextView title = new TextView(this);
        title.setText("8 BALL AIM CALCULATOR");
        title.setTextColor(Color.WHITE);
        title.setTextSize(20);
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(42)));

        TextView subtitle = new TextView(this);
        subtitle.setText("Sentuh posisi bola putih, lalu sentuh bola sasaran");
        subtitle.setTextColor(Color.rgb(205,220,210));
        subtitle.setTextSize(13);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle, new LinearLayout.LayoutParams(-1, dp(34)));

        table = new AimTableView(this);
        LinearLayout.LayoutParams tableParams = new LinearLayout.LayoutParams(-1, 0, 1f);
        tableParams.setMargins(0, dp(8), 0, dp(8));
        root.addView(table, tableParams);

        status = new TextView(this);
        status.setText("Langkah 1: pilih posisi bola putih.");
        status.setTextColor(Color.rgb(245,197,66));
        status.setTextSize(14);
        status.setGravity(Gravity.CENTER);
        root.addView(status, new LinearLayout.LayoutParams(-1, dp(42)));

        Button reset = new Button(this);
        reset.setText("RESET BIDIKAN");
        reset.setTextColor(Color.rgb(25,35,28));
        reset.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(245,197,66)));
        reset.setOnClickListener(v -> {
            table.reset();
            status.setText("Langkah 1: pilih posisi bola putih.");
        });
        root.addView(reset, new LinearLayout.LayoutParams(-1, dp(52)));

        table.setListener(step -> {
            if (step == 1) status.setText("Sekarang sentuh posisi bola sasaran.");
            else status.setText("Garis bidikan dihitung. Sentuh meja lagi untuk mulai bidikan baru.");
        });
        setContentView(root);
    }

    int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    static class AimTableView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float cueX=-1, cueY=-1, objX=-1, objY=-1;
        int step=0;
        float ballR;
        OnStep listener;

        interface OnStep { void changed(int step); }
        AimTableView(Context c) { super(c); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
        void setListener(OnStep l) { listener=l; }
        void reset() { cueX=cueY=objX=objY=-1; step=0; invalidate(); if(listener!=null)listener.changed(0); }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w=getWidth(), h=getHeight();
            c.drawColor(Color.rgb(16,37,29));
            float pad=18, left=pad, top=pad+18, right=w-pad, bottom=h-pad-18;
            float rail=22;
            p.setColor(Color.rgb(104,62,35)); p.setStyle(Paint.Style.FILL);
            c.drawRoundRect(left,top,right,bottom,24,24,p);
            p.setColor(Color.rgb(18,92,58));
            c.drawRoundRect(left+rail,top+rail,right-rail,bottom-rail,12,12,p);
            p.setColor(Color.rgb(9,63,42)); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2);
            c.drawRoundRect(left+rail,top+rail,right-rail,bottom-rail,12,12,p);
            p.setStyle(Paint.Style.FILL);

            float pocketR=10;
            float[][] pockets={{left+rail,top+rail},{(left+right)/2,top+rail},{right-rail,top+rail},
                               {left+rail,bottom-rail},{(left+right)/2,bottom-rail},{right-rail,bottom-rail}};
            p.setColor(Color.BLACK);
            for(float[] q:pockets)c.drawCircle(q[0],q[1],pocketR,p);

            ballR=Math.min((right-left)*0.026f, 13f);
            if(cueX>=0) drawBall(c,cueX,cueY,Color.WHITE,"");
            if(objX>=0) drawBall(c,objX,objY,Color.rgb(238,181,42),"");

            if(cueX>=0 && objX>=0) {
                float dx=objX-cueX, dy=objY-cueY;
                float len=(float)Math.sqrt(dx*dx+dy*dy);
                if(len>0) {
                    float ux=dx/len, uy=dy/len;
                    float ghostX=objX-ux*ballR*2, ghostY=objY-uy*ballR*2;
                    p.setColor(Color.WHITE); p.setStrokeWidth(2.5f); p.setStyle(Paint.Style.STROKE);
                    p.setPathEffect(new DashPathEffect(new float[]{10,7},0));
                    c.drawLine(cueX,cueY,ghostX,ghostY,p);
                    p.setPathEffect(null);
                    p.setColor(Color.rgb(245,197,66)); p.setStrokeWidth(3);
                    c.drawLine(objX,objY,objX+ux*len*0.55f,objY+uy*len*0.55f,p);
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(Color.argb(90,255,255,255));
                    c.drawCircle(ghostX,ghostY,ballR,p);
                    p.setColor(Color.WHITE); p.setTextSize(12);
                    c.drawText("Titik kontak",ghostX+10,ghostY-12,p);
                }
            }
            p.setColor(Color.WHITE); p.setTextSize(12); p.setTypeface(Typeface.DEFAULT_BOLD);
            String hint= step==0 ? "PILIH BOLA PUTIH" : step==1 ? "PILIH BOLA SASARAN" : "GARIS BIDIKAN";
            c.drawText(hint,left+rail,top-5,p);
        }

        void drawBall(Canvas c,float x,float y,int color,String label) {
            p.setStyle(Paint.Style.FILL); p.setColor(Color.argb(80,0,0,0)); c.drawCircle(x+2,y+3,ballR,p);
            p.setColor(color); c.drawCircle(x,y,ballR,p);
            p.setColor(Color.argb(100,255,255,255)); c.drawCircle(x-ballR*.3f,y-ballR*.3f,ballR*.25f,p);
            p.setColor(Color.rgb(30,30,30)); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1); c.drawCircle(x,y,ballR,p); p.setStyle(Paint.Style.FILL);
        }

        @Override public boolean onTouchEvent(android.view.MotionEvent e) {
            if(e.getAction()==MotionEvent.ACTION_UP) {
                float x=e.getX(), y=e.getY();
                float l=18+22, t=18+18+22, r=getWidth()-18-22, b=getHeight()-18-18-22;
                x=Math.max(l+ballR,Math.min(r-ballR,x));
                y=Math.max(t+ballR,Math.min(b-ballR,y));
                if(step==0) { cueX=x; cueY=y; step=1; }
                else if(step==1) { objX=x; objY=y; step=2; }
                else { cueX=x; cueY=y; objX=objY=-1; step=1; }
                invalidate(); if(listener!=null)listener.changed(step); return true;
            }
            return true;
        }
    }
}
